 /** 
* @author  suzw
* @version 创建时间：2018年10月30日 下午2:15:57 
* 类说明 
*/
public class _284_Peeking_Iterator_顶端迭代器 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

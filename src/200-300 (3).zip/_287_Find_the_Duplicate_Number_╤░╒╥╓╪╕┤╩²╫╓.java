/** 
* @author  suzw
* @version 创建时间：2018年10月31日 上午10:41:02 
* 类说明 
* 参考：Linked List  Circle i,ii,141-142
* 建议看：https://blog.csdn.net/willduan1/article/details/50938210
* https://blog.csdn.net/monkeyduck/article/details/50439840
* Linked List Circle2:https://blog.csdn.net/monkeyduck/article/details/40083527
* Given an array nums containing n + 1 integers where each integer is between 1 and n (inclusive), prove that at least one duplicate number must exist. Assume that there is only one duplicate number, find the duplicate one.

Example 1:

Input: [1,3,4,2,2]
Output: 2
Example 2:

Input: [3,1,3,4,2]
Output: 3
Note:

You must not modify the array (assume the array is read only).
You must use only constant, O(1) extra space.
Your runtime complexity should be less than O(n2).
There is only one duplicate number in the array, but it could be repeated more than once.
* 
*/
public class _287_Find_the_Duplicate_Number_寻找重复数字 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
    public static int findDuplicate(int[] nums) {
        int slow = nums[0];
        int fast = nums[nums[0]];
        while(slow!=fast) {
        	slow = nums[slow];
        	fast = nums[nums[fast]];
        }
        fast = 0;
        
        while(fast!=slow) {
        	fast = nums[fast];
        	slow = nums[slow];
        }
    	return fast;
    	
    }
}
